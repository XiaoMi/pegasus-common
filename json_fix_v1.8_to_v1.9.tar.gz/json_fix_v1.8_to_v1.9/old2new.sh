#!/bin/bash

if [ $# -ne 2 ]; then
    echo "$0 <zk_host> <cluster_name>"
    echo "Example: $0 localhost:22181 onebox"
    exit -1
fi

zk_host=$1
cluster=$2

if [ "x$zk_host" == "x" ]; then
    echo "ERROR: empty zk_host"
    exit 1
fi

if [ "x$cluster" == "x" ]; then
    echo "ERROR: empty cluster_name"
    exit 1
fi

cluster_root="/pegasus/$cluster"

./zookeepercli -servers "$zk_host" -c ls "$cluster_root/backup_policy" >tmp.zk.ls.backup_policy
if [ $? -ne 0 ]; then
    echo "ERROR: ls $cluster_root/backup_policy failed"
    exit 1
fi

policy_count=`cat tmp.zk.ls.backup_policy | wc -l`
echo "INFO: policy_count = $policy_count"
echo

echo "INFO: create $cluster_root/backup"
./zookeepercli -servers "$zk_host" -c create "$cluster_root/backup" "" >tmp.zk.create.backup
if [ $? -ne 0 ]; then
    echo "ERROR: create $cluster_root/backup failed"
    exit 1
fi
echo

while read policy; do
    ./zookeepercli -servers "$zk_host" -c ls "$cluster_root/backup_policy/$policy" >tmp.zk.ls.backup_policy.$policy
    if [ $? -ne 0 ]; then
        echo "ERROR: ls $cluster_root/backup_policy/$policy failed"
        exit 1
    fi

    ./zookeepercli -servers "$zk_host" -c get "$cluster_root/backup_policy/$policy" >tmp.zk.get.backup_policy.$policy
    if [ $? -ne 0 ]; then
        echo "ERROR: get $cluster_root/backup_policy/$policy failed"
        exit 1
    fi

    echo "INFO: create $cluster_root/backup/$policy"
    new_policy_json=`cat tmp.zk.get.backup_policy.$policy | ./fix_policy_json.sh`
    echo "-------------------------------------"
    echo "$new_policy_json"
    echo "-------------------------------------"
    ./zookeepercli -servers "$zk_host" -c create "$cluster_root/backup/$policy" "$new_policy_json" >tmp.zk.create.backup.$policy
    if [ $? -ne 0 ]; then
        echo "ERROR: create $cluster_root/backup/$policy failed"
        exit 1
    fi
    echo

    while read backup; do
        ./zookeepercli -servers "$zk_host" -c get "$cluster_root/backup_policy/$policy/$backup" >tmp.zk.get.backup_policy.$policy.$backup
        if [ $? -ne 0 ]; then
            echo "ERROR: get $cluster_root/backup_policy/$policy/$backup failed"
            exit 1
        fi

        echo "INFO: create $cluster_root/backup/$policy/$backup"
        new_backup_json=`cat tmp.zk.get.backup_policy.$policy.$backup | ./fix_backup_json.sh`
        echo "-------------------------------------"
        echo "$new_backup_json"
        echo "-------------------------------------"
        ./zookeepercli -servers "$zk_host" -c create "$cluster_root/backup/$policy/$backup" "$new_backup_json" >tmp.zk.create.backup.$policy.$backup
        if [ $? -ne 0 ]; then
            echo "ERROR: create $cluster_root/backup/$policy/$backup failed"
            exit 1
        fi
        echo
    done <tmp.zk.ls.backup_policy.$policy

done <tmp.zk.ls.backup_policy

rm -f tmp.zk.*

echo "INFO: done"

