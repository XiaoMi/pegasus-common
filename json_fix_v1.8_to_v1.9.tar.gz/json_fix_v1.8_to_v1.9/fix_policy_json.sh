#!/bin/bash
# read old policy info json from stdin and output converted one to stdout
# sample usage: cat test-policy.json | ./fix_policy_json.sh

old_json=`cat -`
segment1=${old_json%\"app_names\":\{*}
segment2_and_3=${old_json#*\"app_names\":\{}
segment2=${segment2_and_3%\},\"backup_interval_seconds\"*}
segment3=${segment2_and_3#*\},\"backup_interval_seconds\"}

OLD_IFS="$IFS"
IFS=","
array=($segment2)
index=0
for item in ${array[*]}; do
    IFS=":"
    pairs=($item)
    IFS=","
    array[$index]=\"${pairs[0]}\":${pairs[1]}
    index=$[ $index + 1 ]
done

new_segment2="${array[*]}"
IFS=$OLD_IFS

echo $segment1"\"app_names\":{"$new_segment2"},\"backup_interval_seconds\""$segment3
