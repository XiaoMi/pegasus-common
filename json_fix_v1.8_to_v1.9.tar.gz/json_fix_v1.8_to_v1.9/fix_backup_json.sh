#!/bin/bash
# read an old backup_info json from stdin and echo converted new one to stdout
# sample_usage: for i in `cat test-backup.json`; do echo $i | ./fix_backup_json.sh; done

old_json=`cat -`
segment1=${old_json%\"app_names\":\{*}
segment2_and_3=${old_json#*\"app_names\":\{}
segment2=${segment2_and_3%\},\"info_status\"*}
segment3=${segment2_and_3#*\},\"info_status\"}

OLD_IFS="$IFS"
IFS=","
array=($segment2)
index=0
for item in ${array[*]}; do
    IFS=":"
    pairs=($item)
    IFS=","
    array[$index]=\"${pairs[0]}\":${pairs[1]}
    index=$[ $index + 1 ]
done

new_segment2="${array[*]}"
IFS=$OLD_IFS

echo $segment1"\"app_names\":{"$new_segment2"},\"info_status\""$segment3
